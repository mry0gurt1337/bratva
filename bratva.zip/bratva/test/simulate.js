// Прогон партий: поднимает сервер в ускоренном режиме и играет N партий
// живыми «клиентами» + ботами. Проверяет, что партии заканчиваются и
// состояние не ломается. Запуск: npm test
process.env.FAST = '1';
process.env.PORT = process.env.PORT || '3999';
const { io } = require('socket.io-client');
const G = require('../public/shared.js');
require('../server.js');

const URL = `http://localhost:${process.env.PORT}`;
const GAMES = Number(process.env.GAMES) || 12;
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const problems = [];
const glokTexts = new Set();

function check(st, tag) {
  for (const p of st.players) {
    if (!Number.isFinite(p.money)) problems.push(`${tag}: money NaN у ${p.name}`);
    if (p.bankrupt && p.money !== 0) problems.push(`${tag}: банкрот с деньгами`);
    if (!p.bankrupt && p.money < 0) problems.push(`${tag}: минус у живого ${p.name} = ${p.money}`);
    if (p.pos < 0 || p.pos >= G.C.N) problems.push(`${tag}: позиция ${p.pos}`);
    if (p.goons < 0 || p.goons > G.C.MAX_GOONS) problems.push(`${tag}: братки ${p.goons}`);
  }
  for (const [id, pr] of Object.entries(st.props)) {
    const o = st.players.find((p) => p.id === pr.owner);
    if (!o || o.bankrupt) problems.push(`${tag}: точка ${id} у мёртвого/несуществующего`);
    if (pr.level < 0 || pr.level > G.C.MAX_LEVEL) problems.push(`${tag}: уровень ${pr.level}`);
  }
  if (st.heat < 0 || st.heat > G.C.MAX_HEAT) problems.push(`${tag}: розыск ${st.heat}`);
}

function client(name) {
  const s = io(URL, { transports: ['websocket'], forceNew: true });
  s.meId = null;
  s.on('you', (y) => { s.meId = y && y.id; s.token = y && y.token; s.code = y && y.code; });
  return s;
}

function game(i, rounds) {
  return new Promise((resolve) => {
    const tag = `игра#${i}`;
    const host = client('host');
    const guest = client('guest');
    let started = false, last = null, decisions = 0, dropped = false, kinds = {};
    const t0 = Date.now();
    const timeout = setTimeout(() => { problems.push(`${tag}: не закончилась за 60с (фаза ${last && last.phase}, круг ${last && last.round})`); done(); }, 60000);
    function done() { clearTimeout(timeout); host.close(); guest.close(); resolve({ tag, rounds: last && last.round, decisions, ms: Date.now() - t0, kinds, winner: last && last.players.find((p) => p.id === last.winner)?.name }); }

    function act(sock, st) {
      if (st.glokTask && sock.meId && !st.glokTask.taps.includes(sock.meId) && Math.random() < 0.5) sock.emit('glok', { seq: st.glokTask.seq });
      const me = st.players[st.turn];
      if (!sock.meId || me.id !== sock.meId) return;
      if (st.phase === 'ROLL') sock.emit('roll');
      else if (st.phase === 'DECIDE' && st.pending) {
        decisions++;
        const q = st.pending;
        const opts = { BUY: ['yes', 'yes', 'no'], UPGRADE: ['yes', 'no'], GYM: ['yes', 'no'], CASINO: [...q.bets || [], 'skip'].map(String), STRELKA: ['pay', 'fight'], JAIL: ['pay', 'wait'] }[q.type];
        sock.emit('decide', { choice: pick(opts) });
        // мусор от «хакера» — сервер должен игнорировать
        sock.emit('decide', { choice: { $evil: 1 } });
        sock.emit('roll');
      }
    }

    host.on('connect', () => host.emit('create', { name: 'Хост' + i, icon: '🚗' }));
    host.on('state', (st) => {
      last = st; check(st, tag);
      for (const l of st.logs) { kinds[l.kind] = 1; if (l.kind === 'glok') glokTexts.add(l.text.split(' — ')[0].slice(0, 40)); }
      if (st.status === 'LOBBY' && !started) {
        if (!guest.joined) { guest.joined = true; guest.emit('join', { code: st.code, name: 'Гость', icon: '💀' }); }
        if (st.players.length < 4 && st.players.length >= 2) host.emit('addBot');
        if (st.players.length === 4) { host.emit('settings', { rounds }); started = true; setTimeout(() => host.emit('start'), 20); }
      }
      if (st.status === 'PLAYING') {
        act(host, st);
        // гость отваливается посреди партии и возвращается по токену
        if (!dropped && st.round === 3) {
          dropped = true; const tok = guest.token; guest.close();
          setTimeout(() => { const g2 = client('g2'); g2.on('connect', () => g2.emit('hello', { token: tok })); g2.on('state', (s) => act(g2, s)); guest.close = () => g2.close(); }, 50);
        }
      }
      if (st.status === 'GAMEOVER') done();
    });
    guest.on('state', (st) => { if (st.status === 'PLAYING') act(guest, st); });
    // попытки хода не в свою очередь
    guest.on('state', () => guest.emit('roll'));
  });
}

(async () => {
  await new Promise((r) => setTimeout(r, 300));
  const results = await Promise.all(Array.from({ length: GAMES }, (_, i) => game(i, process.env.ROUNDS ? Number(process.env.ROUNDS) : (i % 3 === 0 ? 10 : 0))));
  for (const r of results) console.log(`${r.tag}: кругов ${r.rounds}, решений ${r.decisions}, ${r.ms}мс, победил ${r.winner}`);
  const allKinds = Object.assign({}, ...results.map((r) => r.kinds));
  console.log('Глок:', [...glokTexts].length, 'разных событий');
  console.log('Встретились события:', Object.keys(allKinds).sort().join(', '));
  if (problems.length) { console.log('\nПРОБЛЕМЫ:\n' + [...new Set(problems)].slice(0, 30).join('\n')); process.exit(1); }
  console.log(`\nOK: ${GAMES} партий без ошибок`);
  process.exit(0);
})();
