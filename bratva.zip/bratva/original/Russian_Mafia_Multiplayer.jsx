import React, { useState, useEffect, useRef } from 'react';
import { 
  Car, Briefcase, Skull, Target, 
  Dumbbell, Lock, FileText, DollarSign, 
  Crown, Users, Siren, Flame, AlertCircle, TrendingUp, ShieldAlert, Dice5
} from 'lucide-react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, onSnapshot } from 'firebase/firestore';

// --- FIREBASE INIT ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
  projectId: 'demo-project'
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'mafia-monopoly';

// --- CONFIGURATION & BOARD DATA ---
const SPACES = [
  { id: 0, name: 'ОБЩАК', type: 'start', icon: DollarSign, color: 'text-yellow-500' },
  { id: 1, name: 'Ларёк', type: 'property', price: 60, rent: 10, upPrice: 40, group: 'amber-700' },
  { id: 2, name: 'Качалка', type: 'gym', icon: Dumbbell, color: 'text-zinc-300' },
  { id: 3, name: 'Шаурма', type: 'property', price: 80, rent: 15, upPrice: 50, group: 'amber-700' },
  { id: 4, name: 'Тюрьма', type: 'jail', icon: Lock, color: 'text-zinc-500' },
  { id: 5, name: 'Автомойка', type: 'property', price: 100, rent: 20, upPrice: 60, group: 'blue-600' },
  { id: 6, name: 'Качалка', type: 'gym', icon: Dumbbell, color: 'text-zinc-300' },
  { id: 7, name: 'СТО', type: 'property', price: 140, rent: 30, upPrice: 80, group: 'blue-600' },
  { id: 8, name: 'Казино', type: 'random', icon: Dice5, color: 'text-purple-500' },
  { id: 9, name: 'Рынок', type: 'property', price: 160, rent: 35, upPrice: 90, group: 'pink-600' },
  { id: 10, name: 'Качалка', type: 'gym', icon: Dumbbell, color: 'text-zinc-300' },
  { id: 11, name: 'Сауна', type: 'property', price: 200, rent: 45, upPrice: 100, group: 'pink-600' },
  { id: 12, name: 'Менты', type: 'police', icon: ShieldAlert, color: 'text-blue-500' },
  { id: 13, name: 'Клуб', type: 'property', price: 260, rent: 60, upPrice: 120, group: 'emerald-600' },
  { id: 14, name: 'Качалка', type: 'gym', icon: Dumbbell, color: 'text-zinc-300' },
  { id: 15, name: 'Рублевка', type: 'property', price: 400, rent: 100, upPrice: 200, group: 'purple-600' },
];

const getPos = (id) => {
  if (id >= 0 && id <= 3) return { x: id, y: 0 };
  if (id >= 4 && id <= 8) return { x: 3, y: id - 3 };
  if (id >= 9 && id <= 11) return { x: 11 - id, y: 5 };
  if (id >= 12 && id <= 15) return { x: 0, y: 16 - id };
  return { x: 0, y: 0 };
};

const ICONS = { car: Car, briefcase: Briefcase, skull: Skull, target: Target };
const COLORS = ['yellow', 'red', 'blue', 'green'];

export default function App() {
  const [user, setUser] = useState(null);
  const [localInfo, setLocalInfo] = useState({ name: '', icon: 'car' });
  const [roomCode, setRoomCode] = useState('');
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [gameState, setGameState] = useState(null);
  const [localModal, setLocalModal] = useState(null);
  const [error, setError] = useState('');

  const logsEndRef = useRef(null);

  // 1. Auth Setup
  useEffect(() => {
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) {
        console.error("Auth error:", err);
      }
    };
    initAuth();
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return () => unsubscribe();
  }, []);

  // 2. Room Listener
  useEffect(() => {
    if (!user || !roomCode) return;
    const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', roomCode);
    
    const unsubscribe = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        setGameState(snap.data());
      } else {
        setError('Комната не найдена или удалена.');
        setRoomCode('');
      }
    }, (err) => {
      console.error(err);
      setError('Ошибка синхронизации сети.');
    });

    return () => unsubscribe();
  }, [user, roomCode]);

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [gameState?.logs]);

  // --- ROOM MANAGEMENT ---

  const createRoom = async () => {
    if (!user || !localInfo.name) return setError('Введи имя!');
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', code);
    
    const initialPlayer = {
      id: user.uid,
      name: localInfo.name,
      icon: localInfo.icon,
      color: COLORS[0],
      money: 1500,
      auth: 0,
      goons: 0,
      pos: 0
    };

    await setDoc(docRef, {
      status: 'LOBBY',
      hostId: user.uid,
      players: [initialPlayer],
      turnIndex: 0,
      properties: {},
      heat: 0,
      omon: null,
      logs: [`${localInfo.name} создал братву (Код: ${code})`],
      winner: null
    });
    setRoomCode(code);
    setError('');
  };

  const joinRoom = async () => {
    if (!user || !localInfo.name || !joinCodeInput) return setError('Введи имя и код!');
    const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', joinCodeInput);
    const snap = await getDoc(docRef);
    
    if (!snap.exists()) return setError('Неверный код!');
    const data = snap.data();
    if (data.status !== 'LOBBY') return setError('Игра уже идет!');
    if (data.players.length >= 4) return setError('Мест нет (макс 4)!');
    if (data.players.find(p => p.id === user.uid)) {
      setRoomCode(joinCodeInput); // Already in
      return;
    }

    const newPlayer = {
      id: user.uid,
      name: localInfo.name,
      icon: localInfo.icon,
      color: COLORS[data.players.length],
      money: 1500,
      auth: 0,
      goons: 0,
      pos: 0
    };

    const updatedPlayers = [...data.players, newPlayer];
    await updateDoc(docRef, { 
      players: updatedPlayers,
      logs: [...data.logs, `${localInfo.name} примкнул к братве.`].slice(-15)
    });
    setRoomCode(joinCodeInput);
    setError('');
  };

  const startGame = async () => {
    if (!gameState || gameState.hostId !== user.uid || gameState.players.length < 2) return;
    const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', roomCode);
    await updateDoc(docRef, {
      status: 'PLAYING',
      logs: [...gameState.logs, 'ИГРА НАЧАЛАСЬ!'].slice(-15)
    });
  };

  // --- GAMEPLAY LOGIC ---

  const addLog = (gs, msg) => {
    gs.logs.push(msg);
    if (gs.logs.length > 20) gs.logs.shift();
  };

  const syncState = async (newState) => {
    const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', roomCode);
    await updateDoc(docRef, newState);
  };

  const finishTurn = async (gs) => {
    let logMsg = '';
    
    // OMON Mechanics
    if (gs.heat >= 5 && gs.omon === null) {
      gs.omon = 12; // Spawns at Police cell
      addLog(gs, '🚨 ОМОН НАЧАЛ ОБЛАВУ С УЧАСТКА!');
    } else if (gs.omon !== null) {
      gs.omon = gs.omon === 0 ? 15 : gs.omon - 1; // Moves backward
      addLog(gs, `🚨 ОМОН патрулирует клетку ${gs.omon}`);
    }

    // OMON Collision Check
    if (gs.omon !== null) {
      let collisionHit = false;
      gs.players.forEach((p, i) => {
        if (p.pos === gs.omon) {
          collisionHit = true;
          if (p.goons > 0) {
            gs.players[i].goons -= 1;
            addLog(gs, `ОМОН накрыл ${p.name}! Браток отсидел за него.`);
          } else {
            gs.players[i].money -= 200;
            addLog(gs, `ОМОН повязал ${p.name}! Штраф $200.`);
          }
        }
      });
      if (collisionHit) {
        gs.omon = null;
        gs.heat = 0;
        addLog(gs, 'Облава завершена. Розыск сброшен.');
      }
    }

    // Bankrupt Check
    const activePlayers = gs.players.filter(p => p.money >= 0);
    if (activePlayers.length === 1) {
      gs.status = 'GAMEOVER';
      gs.winner = activePlayers[0].id;
      addLog(gs, `👑 ${activePlayers[0].name} ЗАБРАЛ ВЕСЬ ГОРОД!`);
      await syncState(gs);
      return;
    }

    // Next Turn
    let nextIdx = (gs.turnIndex + 1) % gs.players.length;
    // Skip bankrupt players
    while (gs.players[nextIdx].money < 0) {
      nextIdx = (nextIdx + 1) % gs.players.length;
    }
    gs.turnIndex = nextIdx;
    
    await syncState(gs);
  };

  const handleRoll = async () => {
    if (gameState.players[gameState.turnIndex].id !== user.uid) return;

    let gs = JSON.parse(JSON.stringify(gameState)); // Deep copy
    const p = gs.players[gs.turnIndex];
    const roll = Math.floor(Math.random() * 6) + 1;
    let newPos = p.pos + roll;
    
    if (newPos > 15) {
      newPos -= 16;
      p.money += 200;
      addLog(gs, `${p.name} прошел Общак: +$200`);
    }
    p.pos = newPos;
    addLog(gs, `${p.name} бросил ${roll}.`);
    
    // Intermediate sync to show movement on all screens
    await syncState(gs);

    // Wait for token animation, then evaluate space
    setTimeout(() => {
      evalSpace(gs);
    }, 600);
  };

  const evalSpace = async (baseState) => {
    let gs = JSON.parse(JSON.stringify(baseState));
    const p = gs.players[gs.turnIndex];
    const space = SPACES[p.pos];

    if (space.type === 'property') {
      const prop = gs.properties[p.pos];
      if (!prop) {
        if (p.money >= space.price) {
          setLocalModal({ type: 'BUY', space }); // Ask active player
        } else {
          addLog(gs, `${p.name} бомжует, не хватает на ${space.name}`);
          await finishTurn(gs);
        }
      } else if (prop.ownerId === p.id) {
        if (prop.level < 3 && p.money >= space.upPrice) {
          setLocalModal({ type: 'UPGRADE', space, prop });
        } else {
          await finishTurn(gs);
        }
      } else {
        // Enemy Territory
        const owner = gs.players.find(x => x.id === prop.ownerId);
        const rent = space.rent * Math.pow(2, prop.level);
        if (owner && owner.money >= 0) {
          setLocalModal({ type: 'STRELKA', space, prop, rent, owner });
        } else {
          await finishTurn(gs);
        }
      }
    } else if (space.type === 'gym') {
      if (p.money >= 50) {
        setLocalModal({ type: 'GYM' });
      } else {
        await finishTurn(gs);
      }
    } else if (space.type === 'jail' || space.type === 'police') {
      if (p.goons > 0) {
        p.goons -= 1;
        addLog(gs, `${p.name} попал к ментам. Браток отмазал!`);
      } else {
        p.money -= 100;
        addLog(gs, `${p.name} попал к ментам. Штраф $100.`);
      }
      await finishTurn(gs);
    } else if (space.type === 'random') {
      const event = Math.random();
      if (event > 0.5) {
        p.money += 100;
        addLog(gs, `${p.name} поднял в Казино $100.`);
      } else {
        p.money -= 50;
        addLog(gs, `${p.name} просадил в Казино $50.`);
      }
      await finishTurn(gs);
    } else {
      await finishTurn(gs); // Start space
    }
  };

  const resolveModal = async (action) => {
    let gs = JSON.parse(JSON.stringify(gameState));
    const p = gs.players[gs.turnIndex];
    const modal = localModal;
    setLocalModal(null);

    if (modal.type === 'BUY' && action === 'YES') {
      p.money -= modal.space.price;
      gs.properties[p.pos] = { ownerId: p.id, level: 0 };
      gs.heat = Math.min(5, gs.heat + 1);
      addLog(gs, `${p.name} крышует "${modal.space.name}"`);
    }
    if (modal.type === 'UPGRADE' && action === 'YES') {
      p.money -= modal.space.upPrice;
      gs.properties[p.pos].level += 1;
      gs.heat = Math.min(5, gs.heat + 1);
      addLog(gs, `Бизнес "${modal.space.name}" прокачан!`);
    }
    if (modal.type === 'GYM' && action === 'YES') {
      p.money -= 50;
      p.goons += 1;
      addLog(gs, `${p.name} нанял Братка.`);
    }
    if (modal.type === 'STRELKA') {
      const ownerIdx = gs.players.findIndex(x => x.id === modal.owner.id);
      if (action === 'PAY') {
        p.money -= modal.rent;
        if (ownerIdx !== -1) gs.players[ownerIdx].money += modal.rent;
        addLog(gs, `${p.name} молча заплатил $${modal.rent} -> ${modal.owner.name}`);
      } else if (action === 'FIGHT') {
        // Resolve strelka serverlessly via active player's RNG
        const pRoll = Math.floor(Math.random() * 6) + 1 + p.auth;
        const oRoll = Math.floor(Math.random() * 6) + 1 + modal.owner.auth;
        
        if (pRoll > oRoll) {
          gs.properties[p.pos].ownerId = p.id;
          p.auth += 1;
          addLog(gs, `СТРЕЛКА: ${p.name} отжал точку у ${modal.owner.name}!`);
        } else {
          const penalty = modal.rent * 3;
          p.money -= penalty;
          if (ownerIdx !== -1) gs.players[ownerIdx].money += penalty;
          p.auth = Math.max(0, p.auth - 1);
          addLog(gs, `СТРЕЛКА: ${p.name} проиграл! Штраф $${penalty}.`);
        }
      }
    }
    
    await finishTurn(gs);
  };

  // --- RENDERERS ---

  if (!user) {
    return <div className="h-[100dvh] bg-zinc-950 text-white flex items-center justify-center p-4 text-center">Загрузка защищенного соединения...</div>;
  }

  // 1. START SCREEN
  if (!roomCode) {
    return (
      <div className="h-[100dvh] w-full max-w-sm mx-auto bg-zinc-950 text-white flex flex-col items-center justify-center p-6 relative select-none touch-none overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-900/20 via-zinc-950 to-zinc-950" />
        <h1 className="text-4xl font-black text-center mb-1 tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 to-yellow-600 z-10">МАФИЯ</h1>
        <h2 className="text-sm text-zinc-400 tracking-widest mb-8 z-10 uppercase font-black">Сетевая игра</h2>
        
        {error && <div className="text-red-500 bg-red-950/50 p-2 mb-4 rounded border border-red-900 text-xs w-full text-center z-10">{error}</div>}

        <div className="w-full z-10 space-y-4">
          <div>
            <label className="text-xs text-zinc-500 mb-1 block">Твое погоняло</label>
            <input 
              type="text" 
              maxLength={10}
              value={localInfo.name} 
              onChange={e => setLocalInfo({...localInfo, name: e.target.value})}
              className="w-full bg-zinc-900 border border-zinc-700 p-3 rounded text-center text-white outline-none focus:border-yellow-500 font-black uppercase tracking-wider"
              placeholder="БРАТОК"
            />
          </div>

          <div className="grid grid-cols-4 gap-2 mb-6">
            {Object.keys(ICONS).map(key => {
              const Icon = ICONS[key];
              return (
                <button key={key} onClick={() => setLocalInfo({...localInfo, icon: key})} 
                  className={`p-3 rounded-lg flex justify-center border transition-all ${localInfo.icon === key ? 'bg-yellow-600/20 border-yellow-500 text-yellow-500 scale-105' : 'bg-zinc-900 border-zinc-700 text-zinc-500'}`}>
                  <Icon className="w-6 h-6" />
                </button>
              )
            })}
          </div>

          <button onClick={createRoom} className="w-full bg-gradient-to-br from-yellow-600 to-yellow-800 text-black font-black py-4 rounded-lg uppercase tracking-widest hover:brightness-110">
            Создать сходку
          </button>
          
          <div className="relative flex items-center py-2">
            <div className="flex-grow border-t border-zinc-800"></div>
            <span className="flex-shrink-0 mx-4 text-zinc-600 text-xs uppercase font-bold">Или</span>
            <div className="flex-grow border-t border-zinc-800"></div>
          </div>

          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="КОД" 
              maxLength={4}
              value={joinCodeInput}
              onChange={e => setJoinCodeInput(e.target.value)}
              className="w-1/2 bg-zinc-900 border border-zinc-700 p-3 rounded text-center text-white outline-none focus:border-yellow-500 font-black tracking-widest uppercase text-xl"
            />
            <button onClick={joinRoom} className="w-1/2 bg-zinc-800 text-white font-black py-3 rounded uppercase tracking-widest border border-zinc-700 hover:bg-zinc-700">
              Войти
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!gameState) return <div className="h-[100dvh] bg-zinc-950 flex items-center justify-center text-white">Загрузка комнаты...</div>;

  // 2. LOBBY SCREEN
  if (gameState.status === 'LOBBY') {
    return (
      <div className="h-[100dvh] w-full max-w-sm mx-auto bg-zinc-950 text-white flex flex-col p-6 relative select-none touch-none overflow-hidden">
        <h2 className="text-2xl font-black text-center mt-10 mb-2 uppercase text-yellow-500 tracking-widest">Код комнаты:</h2>
        <div className="text-6xl font-black text-center tracking-[0.2em] mb-10 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
          {roomCode}
        </div>

        <div className="flex-1">
          <p className="text-zinc-500 text-sm uppercase mb-4 font-black">Братва ({gameState.players.length}/4):</p>
          <div className="space-y-3">
            {gameState.players.map((p, i) => {
              const Icon = ICONS[p.icon];
              return (
                <div key={p.id} className="flex items-center gap-4 bg-zinc-900 p-4 rounded-lg border border-zinc-800">
                  <div className={`text-${p.color}-500`}><Icon className="w-6 h-6" /></div>
                  <span className="font-black uppercase tracking-wider text-lg">{p.name} {p.id === gameState.hostId && '👑'}</span>
                  {p.id === user.uid && <span className="ml-auto text-xs text-green-500 font-bold uppercase">(Ты)</span>}
                </div>
              );
            })}
          </div>
        </div>

        {gameState.hostId === user.uid ? (
          <button onClick={startGame} disabled={gameState.players.length < 2} className="bg-yellow-600 disabled:bg-zinc-800 text-black disabled:text-zinc-500 py-4 rounded-lg font-black uppercase tracking-widest mb-10 transition-colors">
            {gameState.players.length < 2 ? 'Ждем братков...' : 'Начать замес'}
          </button>
        ) : (
          <div className="text-center text-zinc-500 mb-10 uppercase font-black animate-pulse">Ожидаем хоста...</div>
        )}
      </div>
    );
  }

  // 3. GAMEOVER
  if (gameState.status === 'GAMEOVER') {
    const winner = gameState.players.find(p => p.id === gameState.winner);
    return (
      <div className="h-[100dvh] w-full max-w-sm mx-auto bg-zinc-950 text-white flex flex-col items-center justify-center p-6 relative select-none touch-none">
        <Crown className="w-24 h-24 mb-6 text-yellow-500 drop-shadow-[0_0_20px_rgba(234,179,8,0.8)]" />
        <h1 className="text-3xl font-black mb-2 uppercase text-center">{winner?.name || 'Никто'} <br/>забрал город</h1>
        <button onClick={() => window.location.reload()} className="mt-10 bg-zinc-800 text-white px-8 py-3 rounded border border-zinc-600 font-black uppercase">Выйти</button>
      </div>
    );
  }

  // 4. PLAYING SCREEN
  const isMyTurn = gameState.players[gameState.turnIndex]?.id === user.uid;

  return (
    <div className="h-[100dvh] w-full max-w-sm mx-auto bg-zinc-950 flex flex-col relative select-none touch-none overflow-hidden text-white font-sans">
      <div className="w-full h-full p-1 pb-4 relative flex items-center justify-center">
        {/* BOARD GRID */}
        <div className="w-full aspect-[2/3] relative">
          <div className="absolute inset-0 grid grid-cols-4 grid-rows-6 border border-zinc-800 bg-zinc-950 shadow-2xl">
            {[...Array(24)].map((_, i) => {
              const col = i % 4;
              const row = Math.floor(i / 4);
              let id = null;
              if (row === 0) id = col;
              else if (row === 5) id = 11 - col;
              else if (col === 3) id = row + 3;
              else if (col === 0) id = 16 - row;

              if (id !== null) {
                const space = SPACES[id];
                const prop = gameState.properties[id];
                let borderCol = 'border-zinc-800/80';
                if (prop) {
                  const ownerInfo = gameState.players.find(p => p.id === prop.ownerId);
                  if (ownerInfo) borderCol = `border-${ownerInfo.color}-500`;
                }

                return (
                  <div key={i} className={`border ${borderCol} ${prop ? 'bg-zinc-900/60' : 'bg-zinc-900'} relative flex flex-col items-center justify-center overflow-hidden transition-colors`}>
                    {space.group && <div className={`absolute top-0 left-0 w-full h-[4px] bg-${space.group.split('-')[0]}-${space.group.split('-')[1]}`} />}
                    
                    {space.icon && <space.icon className={`w-5 h-5 mb-1 opacity-70 ${space.color}`} />}
                    <span className="text-[8px] font-bold text-zinc-300 uppercase leading-none text-center px-1 break-words">{space.name}</span>
                    {space.price && <span className="text-[7px] text-zinc-500 mt-1">${space.price}</span>}

                    {prop && prop.level > 0 && (
                      <div className="absolute bottom-0.5 flex gap-[1px]">
                        {[...Array(prop.level)].map((_, idx) => (
                          <div key={idx} className="w-1.5 h-1.5 bg-yellow-500 rounded-sm clip-star" style={{ clipPath: 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)' }}/>
                        ))}
                      </div>
                    )}
                  </div>
                );
              }
              return <div key={i} className="bg-transparent" />; // Empty Center
            })}
          </div>

          {/* DASHBOARD */}
          <div className="absolute top-[16.666%] left-[25%] w-[50%] h-[66.666%] bg-black/90 backdrop-blur-md rounded-xl border border-zinc-700 shadow-[inset_0_0_30px_rgba(0,0,0,1)] flex flex-col p-1.5 z-10">
            
            {/* Heat */}
            <div className="flex justify-center gap-1 mb-1 mt-1">
              {[...Array(5)].map((_, i) => (
                <Flame key={i} className={`w-3.5 h-3.5 ${i < gameState.heat ? 'text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.8)]' : 'text-zinc-800'}`} />
              ))}
            </div>

            {/* Players List */}
            <div className="flex flex-col gap-1 w-full mb-auto overflow-y-auto pr-1 custom-scrollbar">
              {gameState.players.map((p, i) => (
                <div key={p.id} className={`flex items-center p-1 rounded border ${gameState.turnIndex === i ? `border-${p.color}-500 bg-zinc-900` : 'border-zinc-800 bg-transparent'} ${p.money < 0 ? 'opacity-30 grayscale' : ''}`}>
                  <div className={`w-1.5 h-full rounded-l bg-${p.color}-500 mr-1`} />
                  <div className="flex-1 min-w-0">
                    <div className="text-[9px] font-black uppercase text-zinc-300 truncate">{p.name} {p.id===user.uid && '(Ты)'}</div>
                    <div className="flex gap-2 text-[8px] font-mono mt-0.5">
                      <span className={p.money < 0 ? 'text-red-500' : 'text-green-400'}>${p.money}</span>
                      <span className="text-yellow-500 flex items-center gap-0.5"><Crown className="w-2 h-2"/>{p.auth}</span>
                      <span className="text-zinc-400 flex items-center gap-0.5"><Users className="w-2 h-2"/>{p.goons}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Action Area */}
            <div className="my-2 flex justify-center">
              <button 
                onClick={handleRoll}
                disabled={!isMyTurn || localModal !== null}
                className={`w-[90%] py-2.5 rounded shadow-lg border uppercase text-[9px] font-black tracking-widest transition-all
                  ${isMyTurn && !localModal
                    ? 'bg-gradient-to-br from-yellow-600 to-yellow-800 text-black border-yellow-400/50 hover:brightness-110 active:scale-95 animate-pulse'
                    : 'bg-zinc-900 text-zinc-600 border-zinc-800'}`}
              >
                {isMyTurn ? (localModal ? 'Ожидание...' : 'Бросить кубик') : 'Ход соперника'}
              </button>
            </div>

            {/* Logs */}
            <div className="mt-auto h-20 overflow-y-auto bg-black rounded border border-zinc-800 p-1 flex flex-col text-[8px] font-mono leading-tight space-y-1">
              {gameState.logs.map((l, i) => (
                <div key={i} className={`${i === gameState.logs.length - 1 ? 'text-zinc-200' : 'text-zinc-600'}`}>
                  {'>'} {l}
                </div>
              ))}
              <div ref={logsEndRef} />
            </div>
          </div>

          {/* TOKENS LAYER */}
          <div className="absolute inset-0 pointer-events-none z-20">
            {gameState.players.map((p, i) => {
              if (p.money < 0) return null; // Hide bankrupt
              const Icon = ICONS[p.icon];
              // Offset tokens slightly to avoid complete overlap
              const offsets = [{x:-4,y:-4}, {x:4,y:-4}, {x:-4,y:4}, {x:4,y:4}];
              const off = offsets[i % 4];
              
              return (
                <div 
                  key={p.id}
                  className="absolute w-1/4 h-[16.666%] flex items-center justify-center transition-all duration-500 ease-out"
                  style={{ left: `${getPos(p.pos).x * 25}%`, top: `${getPos(p.pos).y * 16.666}%`, transform: `translate(${off.x}px, ${off.y}px)` }}
                >
                  <div className={`w-5 h-5 bg-${p.color}-500 rounded-full border border-black flex items-center justify-center shadow-[0_0_10px_rgba(0,0,0,0.8)] z-30`}>
                    <Icon className="text-black w-3 h-3" />
                  </div>
                </div>
              )
            })}

            {gameState.omon !== null && (
              <div 
                className="absolute w-1/4 h-[16.666%] flex items-center justify-center transition-all duration-500 ease-out z-40"
                style={{ left: `${getPos(gameState.omon).x * 25}%`, top: `${getPos(gameState.omon).y * 16.666}%`, transform: 'translate(0, -12px)' }}
              >
                <div className="w-5 h-5 bg-blue-600 rounded border border-red-500 flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.9)] animate-pulse">
                  <Siren className="text-white w-3 h-3 animate-spin" style={{ animationDuration: '2s' }}/>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* LOCAL MODALS (Only active player sees this) */}
      {localModal && isMyTurn && (
        <div className="absolute inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl p-4 w-full max-w-[260px] shadow-2xl">
            
            {localModal.type === 'BUY' && (
              <div className="text-center">
                <h3 className="text-base font-black uppercase text-yellow-500 mb-1">{localModal.space.name}</h3>
                <p className="text-[10px] text-zinc-400 mb-4">Берем точку под крышу?</p>
                <div className="bg-zinc-950 rounded p-2 mb-4 flex flex-col text-[10px] font-mono gap-1">
                  <div className="flex justify-between"><span className="text-zinc-500">Цена:</span><span className="text-red-400">-${localModal.space.price}</span></div>
                  <div className="flex justify-between"><span className="text-zinc-500">Доход:</span><span className="text-green-400">+$${localModal.space.rent}</span></div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => resolveModal('YES')} className="flex-1 bg-green-700 hover:bg-green-600 py-2 rounded text-[10px] uppercase font-black">Купить</button>
                  <button onClick={() => resolveModal('NO')} className="flex-1 bg-zinc-800 hover:bg-zinc-700 py-2 rounded text-[10px] uppercase font-black">Пас</button>
                </div>
              </div>
            )}

            {localModal.type === 'UPGRADE' && (
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <h3 className="text-base font-black uppercase text-zinc-100 mb-1">Прокачка</h3>
                <div className="bg-zinc-950 rounded p-2 mb-4 flex flex-col text-[10px] font-mono gap-1">
                  <div className="flex justify-between"><span className="text-zinc-500">Рента сейчас:</span> <span className="text-green-400">${localModal.space.rent * Math.pow(2, localModal.prop.level)}</span></div>
                  <div className="flex justify-between"><span className="text-zinc-500">Новая рента:</span> <span className="text-green-500 font-bold">${localModal.space.rent * Math.pow(2, localModal.prop.level + 1)}</span></div>
                  <div className="flex justify-between mt-1 pt-1 border-t border-zinc-800"><span className="text-zinc-500">Цена:</span> <span className="text-red-400">-${localModal.space.upPrice}</span></div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => resolveModal('YES')} className="flex-1 bg-yellow-600 text-black py-2 rounded text-[10px] uppercase font-black">Улучшить</button>
                  <button onClick={() => resolveModal('NO')} className="flex-1 bg-zinc-800 py-2 rounded text-[10px] uppercase font-black">Отмена</button>
                </div>
              </div>
            )}

            {localModal.type === 'GYM' && (
              <div className="text-center">
                <Users className="w-8 h-8 text-zinc-300 mx-auto mb-2" />
                <h3 className="text-base font-black uppercase text-zinc-100 mb-2">Качалка</h3>
                <p className="text-[10px] text-zinc-400 mb-4">Найм: <span className="text-red-400">-$50</span>. Спасет от ментов.</p>
                <div className="flex gap-2">
                  <button onClick={() => resolveModal('YES')} className="flex-1 bg-zinc-200 text-black py-2 rounded text-[10px] uppercase font-black">Нанять</button>
                  <button onClick={() => resolveModal('NO')} className="flex-1 bg-zinc-800 py-2 rounded text-[10px] uppercase font-black">Уйти</button>
                </div>
              </div>
            )}

            {localModal.type === 'STRELKA' && (
              <div className="text-center">
                <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-2 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]" />
                <h3 className="text-base font-black uppercase text-red-500 mb-1">Чужая территория</h3>
                <p className="text-[9px] text-zinc-400 mb-3 uppercase tracking-widest text-center">{localModal.space.name} (Владелец: {localModal.owner.name})</p>
                
                <div className="bg-zinc-950 rounded p-2 mb-3 text-[10px] font-mono text-left space-y-1">
                  <div className="flex justify-between"><span>Доля:</span> <span className="text-red-400">-${localModal.rent}</span></div>
                  <div className="flex justify-between"><span>Риск стрелки:</span> <span className="text-yellow-500">Кубик+Авторитет</span></div>
                </div>

                <div className="flex flex-col gap-2">
                  <button onClick={() => resolveModal('PAY')} className="w-full bg-zinc-800 text-zinc-300 py-2.5 rounded text-[9px] uppercase font-black border border-zinc-600">
                    Заплатить ${localModal.rent}
                  </button>
                  <button onClick={() => resolveModal('FIGHT')} className="w-full bg-red-700 text-white py-2.5 rounded text-[9px] uppercase font-black border border-red-500 shadow-[0_0_10px_rgba(220,38,38,0.3)]">
                    Стрелка (Отжать точку)
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}
    </div>
  );
}